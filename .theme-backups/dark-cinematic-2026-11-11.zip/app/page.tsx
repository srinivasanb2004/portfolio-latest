import CinematicScene from '@/components/CinematicScene';
import HeroSection from '@/components/sections/HeroSection';
import AboutSection from '@/components/sections/AboutSection';
import SkillsSection from '@/components/sections/SkillsSection';
import ExperienceSection from '@/components/sections/ExperienceSection';
import ProjectsSection from '@/components/sections/ProjectsSection';
import ContactSection from '@/components/sections/ContactSection';
import PortfolioChatbot from '@/components/PortfolioChatbot';

import Footer from '@/components/Footer';

export default function Home() {
  return (
    <main className="relative isolate">
      <section id="home" className="cinematic-section">
        <CinematicScene chapter="01" label="Introduction" />
        <HeroSection />
      </section>

      <section id="about" className="cinematic-section">
        <CinematicScene chapter="02" label="The person" />
        <AboutSection />
      </section>

      <section id="skills" className="cinematic-section">
        <CinematicScene chapter="03" label="The toolkit" />
        <SkillsSection />
      </section>

      <section id="experience" className="cinematic-section">
        <CinematicScene chapter="04" label="The journey" />
        <ExperienceSection />
      </section>

      <section id="projects" className="cinematic-section">
        <CinematicScene chapter="05" label="Selected work" />
        <ProjectsSection />
      </section>

      <section id="contact" className="cinematic-section">
        <CinematicScene chapter="06" label="Next chapter" />
        <ContactSection />
      </section>

      <Footer/>
      <PortfolioChatbot />
    </main>
  );
}
