import Image from 'next/image';
import { ArrowDown, ArrowUpRight } from 'lucide-react';
import Reveal from '@/components/Reveal';

export default function HeroSection() {
  return (
    <section className="hero-stage">
      <div className="hero-orbit" aria-hidden="true"><i /><i /><i /></div>
      <div className="hero-topline"><span>INDEPENDENT DEVELOPER & CREATIVE THINKER</span><span>BASED IN COIMBATORE, INDIA</span></div>
      <div className="hero-composition">
        <div className="hero-copy">
          <Reveal><p className="eyebrow"><span className="status-dot" /> AVAILABLE FOR OPPORTUNITIES</p></Reveal>
          <Reveal delay={0.12}><h1>Thoughtfully built.<br /><em>Distinctly</em><br />human.</h1></Reveal>
          <Reveal delay={0.24}><p className="hero-intro">I’m Srinivasan B. A full stack developer turning complex ideas into intuitive digital experiences.</p></Reveal>
          <Reveal delay={0.36} className="hero-actions"><a className="lux-button" href="#projects">Explore my work <ArrowUpRight size={18} /></a><a className="text-link" href="#contact">Let’s talk <ArrowUpRight size={17} /></a></Reveal>
        </div>
        <Reveal delay={0.25} className="hero-portrait">
          <div className="portrait-frame"><Image src="/me.jpg" alt="Srinivasan B, full stack developer" fill priority sizes="(max-width: 767px) 85vw, 40vw" className="portrait-image" /><div className="portrait-shade" /><span className="portrait-index">SB / 01</span><div className="portrait-caption"><span>THE PERSON BEHIND THE PIXELS</span><strong>Srinivasan B.</strong><small>Full Stack Developer</small></div></div>
          <div className="portrait-note">CRAFT. CODE. CONSIDERATION.</div>
        </Reveal>
      </div>
      <div className="hero-bottom"><a href="#about"><ArrowDown size={16} /> SCROLL TO DISCOVER</a><span>REACT / NEXT.JS / NODE.JS / MONGODB</span><span>PORTFOLIO — 2026</span></div>
    </section>
  );
}
