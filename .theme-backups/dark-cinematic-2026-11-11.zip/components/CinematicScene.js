/** Decorative layers stay underneath the content and never capture input. */
export default function CinematicScene({ chapter, label }) {
  return <div className="cinematic-scene" aria-hidden="true">
    <div className="scene-light scene-light-primary" />
    <div className="scene-light scene-light-secondary" />
    <div className="scene-ribbons"><i /><i /><i /></div>
    <div className="scene-orbits"><i /><i /><i /></div>
    <div className="scene-grid" />
    <div className="scene-grain" />
    <div className="scene-chapter"><span>{chapter}</span><small>{label}</small></div>
    <div className="scene-horizon" />
  </div>;
}
